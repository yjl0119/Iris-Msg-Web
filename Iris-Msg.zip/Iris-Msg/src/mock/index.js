import Mock from "mockjs";
let debug = 1;
if (debug) {
  Mock.mock(/login/, {
    data: {
      userId: "@integer(1,10)",
      "userName|1": ["Tommy","Max","Tom","Jayce"],
      token: "@string(30)"
    },
    msg: "Success",
    status: "YQ-000"
  });
  Mock.mock(/getMenu/, {
    data: {
      menu: [
        {
          name: "Organisations",
          router: "/organisations",
          children: []
        },
        {
          name: "Donations",
          router: "/donations",
          children: []
        },
        {
          name: "Donate Sms",
          router: "/donateNumber",
          children: []
        },
        {
          name: "About",
          router: "/",
          children: [
            {
              name: "About Iris Msg",
              router: "/about1",
            },
            {
              name: "About Open Lab",
              router: "/about2"
            }
          ]
        }
      ]
    },
    msg: "Success",
    status: "YQ-000"
  });
}
