import axios from 'axios'
import router from './router'

// 构建请求对象
axios.defaults.timeout = 8000;
axios.defaults.baseURL = 'https://api.irismsg.io/';

// 请求拦截器
axios.interceptors.request.use(config => {
    // 如果本地存储中有token字段， 就为所有请求加上Authorization请求头
    console.log("beilanjie")
    if (localStorage.token) {
      console.log("xiugaibiaotou");
      config.headers.Authorization = 'Bearer '+localStorage.token;
      console.log(config.headers.Authorization);
    }
    return config;
  },
  error => {
    console.log(error) // for debug
    Promise.reject(error)
  })



export default axios
