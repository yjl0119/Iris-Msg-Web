import axios from 'axios' //如果有action

const module1 = {
    state: {

    },
    getters: {

    },
    mutations: {

    },
    actions: {
        // search({ commit }) {
        //     axios({

        //     }).then(res => {
        //         console.log(res)
        //     }).catch(error => {
        //         console.log(error)
        //     })
        // }
    }
}

export default module1
