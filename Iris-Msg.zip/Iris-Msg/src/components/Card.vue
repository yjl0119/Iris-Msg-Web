<template>
    <div id="card">
      <a-card title="Card Title">
      <a href="#" slot="extra">more</a>
      <p>card content</p>
      <p>card content</p>
      <p>card content</p>
  </a-card>
    </div>
</template>

<script>
export default {

}
</script>

<style>

</style>