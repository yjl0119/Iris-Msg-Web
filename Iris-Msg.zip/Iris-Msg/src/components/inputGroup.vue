<template>
    <div class="text_group">
    </div>
</template>

<script>
export default {
    name:"inputGroup"
    


}
</script>

<style>

</style>
