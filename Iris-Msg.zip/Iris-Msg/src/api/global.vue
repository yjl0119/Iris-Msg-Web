<template>
      <div> </div>      
</template>


<!-- API全局变量 -->
<script>    
    // 本地 接口地址
    const localSrc = 'http://192.168.0.103:8444'; 
    // 线上 接口地址
    const serverSrc = 'https://api.irismsg.io';

    export default{
        localSrc,
        serverSrc
    }
</script>

<style>
</style>
