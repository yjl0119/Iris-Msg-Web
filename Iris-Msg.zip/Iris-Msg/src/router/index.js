import Vue from "vue";
import Router from "vue-router";
Vue.use(Router);


const Signin = () => import ("@/views/signin")

// const Layout = () => import("@/views/layout")

// 项目信息
const Organisations = () => import("@/views/organisations")

// 关于作者
const Donations = () => import("@/views/donations")

// 天气预报
const DonateNumber = () => import("@/views/donateNumber")
// 立方体
const About1 = () => import("@/views/about1")
// 空白页面
const About2 = () => import("@/views/about2")
const Notfound = () => import("@/views/404")
const router = new Router({
  routes: [
    // 首先是登录页的路由
    {
      path: "/signin",
      name: "Signin",
      meta: {
        title: "Iris Msg"
      },
      component: Signin
    },
    {
      path: "organisations",
      meta: {
        title: "Organisations",
        requireAuth : true
      },
      component: Organisations
    },
    {
      path: "donations",
      meta: {
        title: "Donations",
        requireAuth : true
      },
      component: Donations
    },
    {
      path: "donateNumber",
      meta: {
        title: "DonateNumber",
        requireAuth : true
      },
      component: DonateNumber
    },
    {
      path: "about1",
      meta: {
        title: "About Iris Msg"
      },
      component: About1
    },
    {
      path: "about2",
      meta: {
        title: "About Open Lab"
      },
      component: About2
    }
    
  ]
});


router.beforeEach((to, from, next) => {
  if (to.meta.requireAuth){
  if (localStorage.token){
    document.title = "Iris Msg";
    next();
  }else{
    next({
      path: '/signin',
      query: {redirect : to.fullPath}
    })
  }
  }else {
    document.title = "Iris Msg";
    next();
  }
});

export default router;
