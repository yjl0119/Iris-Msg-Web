import Vue from "vue";
import Router from "vue-router";
Vue.use(Router);
const Signin = () => import("@/views/signin")

// 非登录页的包裹组件
const Layout = () => import("@/views/layout")

// 项目信息
const Organisations = () => import("@/views/organisations")

// 关于作者
const Donations = () => import("@/views/donations")

// 天气预报
const DonateNumber = () => import("@/views/donateNumber")
// 立方体
const About1 = () => import("@/views/about1")
// 空白页面
const About2 = () => import("@/views/about2")
// 404
const Notfound = () => import("@/views/404")

const router = new Router({
  routes: [
    // 首先是登录页的路由
    {
      path: "/",
      name: "Signin",
      meta: {
        title: "Iris Msg"
      },
      component: Signin
    },
    // 然后就是嵌套路由了，也就是登陆后的各个页面
    {
      path: "/",
      component: Layout,
       redirect: '/organisations', // 重定向到第一个子路由，否则只渲染Layout组件，这块儿使用时解除注释
      //redirect: "/signin", // 这里重定向到登录页面，是为了展示使用，实际用这个项目开发时，需要注释这行，解除上一行的注释
      children: [
        {
          path: "organisations",
          meta: {
            title: "Organisations"
          },
          component: Organisations
        },
        {
          path: "donations",
          meta: {
            title: "Donations"
          },
          component: Donations
        },
        {
          path: "donateNumber",
          meta: {
            title: "DonateNumber"
          },
          component: DonateNumber
        },
        {
          path: "about1",
          meta: {
            title: "About Iris Msg"
          },
          component: About1
        },
        {
          path: "about2",
          meta: {
            title: "About Open Lab"
          },
          component: About2
        }
      ]
    },
    {
      path: "*",
      meta: {
        title: "404"
      },
      component: Notfound
    }
  ]
});

// 当一个导航触发时，全局的 before 钩子按照创建顺序调用。钩子是异步解析执行，此时导航在所有钩子 resolve 完之前一直处于等待中。
router.beforeEach((to, from, next) => {
  // 自动化修改页面标签的 title
  document.title = to.meta.title;

  const isLogin = localStorage.ele_login ? true : false;
  if (to.path === "/signin") {
    next();
  } else {
    isLogin ? next() : next("/signin");
  }

});

export default router;
