<template>
<!-- Card -->
<div id="app">
    <el-col class="card" v-for="v in msg" :key="v" :offset="1">
        <div @click="dialogFormVisible2 = true;nowOrg =v;getOrg(v)">
            <el-card shadow="hover">
                <div slot="header" class="clearfix">
                    <span>{{v.name}}</span>
                    <el-button onClick="event.cancelBubble = true" style="position:absolute; right:20px; padding: 7px 7px" type="danger" icon="el-icon-delete" @click="del(v._id)" circle></el-button>
                </div>
                <div class="text item">
                    Info:{{v.info}}
                </div>
            </el-card>
        </div>
    </el-col>

    <!-- Create New card -->
    <el-col class="create" :offset="1">
        <el-card shadow="hover">
            <div class="icon">
                <el-button class="button" type="primary" icon="el-icon-plus" @click="dialogFormVisible = true"></el-button>
                <el-dialog title="Create Organisation" :visible.sync="dialogFormVisible" :modal-append-to-body='false'>
                    <el-form :model="form">
                        <el-form-item label="Name" :label-width="formLabelWidth">
                            <el-input v-model="form.name" autocomplete="off"></el-input>
                        </el-form-item>
                        <el-form-item label="Info" :label-width="formLabelWidth">
                            <el-input v-model="form.info" autocomplete="off"></el-input>
                        </el-form-item>
                    </el-form>
                    <div slot="footer" class="dialog-footer">
                        <el-button @click="dialogFormVisible = false">Cancel</el-button>
                        <el-button type="primary" @click="dialogFormVisible = false;create()">Confirm</el-button>
                    </div>
                </el-dialog>
            </div>
        </el-card>

    </el-col>
    <!-- Help button -->
    <div class="help">
        <i title="Help" class="el-icon-question" @click="dialogFormVisible3 = true"></i>
    </div>
    <el-dialog title="How to create an organisation" :visible.sync="dialogFormVisible3" :modal-append-to-body='false'>
       <div>
         <el-steps :active="active" finish-status="success">
       <el-step title="Create Org"></el-step>
       <el-step title="Input info"></el-step>
       <el-step title="Click the Card"></el-step>
       <el-step title="Working!"></el-step>
      </el-steps>
      <img v-if="active == 1" src="../assets/Help-1.png" />
      <img v-if="active == 2" src="../assets/Help-2.png" />
      <img v-if="active == 3" src="../assets/Help-3.png" />
      <img v-if="active == 4" src="../assets/Help-4.png" />
       </div>
        <el-button type="primary" :icon="iconMeau[active]" @click="nextStep()" style="position:relative; top:3px; padding: 10px 10px;float:right">{{textMeau[active]}}</el-button>
       <div class="clear"></div>
      
    </el-dialog>
    <!-- Send Message and manage the member -->
    <el-dialog :title="nowOrg.name" :visible.sync="dialogFormVisible2" :modal-append-to-body='false'  @closed="handleClose">
        <el-tabs v-model="activeName" @tab-click="handleClick">
            <el-tab-pane label="Send Message" name="first">
                <div>
                    <el-input type="textarea" :rows="2" placeholder="Please input messages" v-model="textarea">
                    </el-input>
                    <el-button type="primary" icon="el-icon-edit" @click="sendMessage(nowOrg._id)" style="position:relative; top:3px; padding: 10px 10px;float:right">Send</el-button>
                </div>
                <div class="clear"></div>
                <div>Send a message to you organisation through it's donors.<br>
                    Donors will receive a notification where they have the option to forward the message on to subscribers.<br>
                    If a donor cannot donate, another donor will be asked instead.
                </div>
            </el-tab-pane>
            <el-tab-pane label="Member View" name="second">
                <el-table ref="filterTable" :data="org_msg" style="width: 100%"   >
                    <el-table-column prop="label" label="Name" width="180">
                    </el-table-column>
                    <el-table-column prop="phoneNumber" label="Phone Number" :formatter="formatter">
                    </el-table-column>
                    <el-table-column prop="tag" label="Role" width="100" :filters="[{ text: 'coordinator', value: 'coordinator' },{ text: 'donor', value: 'donor' },{ text: 'subscriber', value: 'subscriber' }]" :filter-method="filterTag" filter-placement="bottom-end">
                        <template slot-scope="scope">
                            <el-tag :type="scope.row.role === 'coordinator' ? 'primary' : 'success'" disable-transitions>{{scope.row.role}}</el-tag>
                        </template>
                    </el-table-column>
                    <el-table-column label="Operation">
                        <template slot-scope="scope">
                            <el-button size="mini" type="danger" @click="handleDelete(scope.$index, scope.row);reload()">Delete</el-button>
                        </template>
                    </el-table-column>
                </el-table>
            </el-tab-pane>
            <el-tab-pane label="Create Member" name="third">
                Phone Number:<el-input placeholder="Please input phone number" v-model="inputPhone" clearable>
                </el-input>
                Name:<el-input placeholder="Please input name(optional)" v-model="labelName" clearable>
                </el-input>
                Role:
                <div>
                    <el-radio v-model="radio1" label="donor" border>Donor</el-radio>
                    <el-radio v-model="radio1" label="subscriber" border>Subscriber</el-radio>
                    <el-button type="primary" icon="el-icon-plus" @click="createMember(nowOrg._id);reload()" style="position:relative; top:3px; padding: 10px 10px;float:right">Create</el-button>
                </div>

            </el-tab-pane>
        </el-tabs>

    </el-dialog>
    
</div>
</template>

<script>
import Vue from 'vue'
import Vuetify from 'vuetify' // Import Vuetify to your project
import axios from "axios"

Vue.use(Vuetify) // Add Vuetify as a plugin
export default {
    name: "app",
    data() {
        return {
            msg: '',
            org_msg: '',
            textarea: '',
            nowOrg: '',
            dialogFormVisible: false,
            dialogFormVisible2: false,
            dialogFormVisible3: false,
            form: {
                name: '',
                info: '',
            },
            iconMeau:["el-icon-right","el-icon-right","el-icon-right","el-icon-right","el-icon-refresh-right"],
            textMeau:["next","next","next","next","Replay"],
            active:1,
            activeName: 'first',
            formLabelWidth: '120px',
            radio1: 'donor',
            inputPhone: '',
            labelName: ''
        }
    },
    mounted: function () {
        this.get();
        setInterval(this.get(), 10000);

    },
    computed: {
        listDonor: function () {
            return this.org_msg.phoneNumber.filter(function (item) {
                return item.role === 'donor'
            })
        }
    },
    methods: {
        get() {
            var serverPath = this.GLOBAL.serverSrc;
            console.log('aaa')
            console.log(this.items);
            console.log(localStorage.token);
            let _this = this;
            axios.get(serverPath + '/organisations').then(res => {
                console.log(res);
                console.log(res.data.data.length);
                this.msg = res.data.data;
                console.log(this.msg);
            });
        },
        nextStep() {
        if (this.active++ > 3) this.active = 1;
        },
        create() {
            console.log(this.form);
            const name = this.form.name;
            const info = this.form.info;
            var serverPath = this.GLOBAL.serverSrc;
            axios.post(serverPath + '/organisations', {
                "name": name,
                "info": info
            });
            location.reload();
        },
        refresh() {
            this.$router.replace({
                path: '/empty',
                query: {
                    t: Date.now()
                }
            })
        },
        del(id) {
            const _id = id;
            console.log("shanchuzhong")
            console.log(_id)
            var serverPath = this.GLOBAL.serverSrc;
            axios.delete(serverPath + '/organisations/' + _id).then(res => {
                if (res.status == 200) {
                    console.log("success");
                } else {
                    console.log("false");
                }
            });
            location.reload();
        },
        sendMessage(id) {
            const _id = id;
            const content = this.textarea;
            let _this = this;
            console.log("sending");
            console.log(_id);
            console.log(content);
            var serverPath = this.GLOBAL.serverSrc;
            axios.post(serverPath + '/messages/', {
                "orgId": _id,
                "content": content
            }).then(res => {
                console.log(res)
                if (res.status == 200) {
                    console.log("success")
                    _this.open2();
                } else {
                    console.log("false")
                }
            }, err => {
                open3();
            });
        },

        reload() {
            this.$forceUpdate();
        },
        createMember(id) {
            const _id = id;
            let _this = this;
            const countryCode = "GB";
            const phoneNumber = this.inputPhone.substring(3);
            const role = this.radio1;
            const label = this.labelName;
            var serverPath = this.GLOBAL.serverSrc;
            axios.post(serverPath + '/organisations/' + _id + '/members', {
                "phoneNumber": phoneNumber,
                "countryCode": countryCode,
                "role": role,
                "label": label,
            }).then(res => {
                console.log(res)
                if (res.status == 200) {
                    console.log("success")
                    _this.open2();
                }
            }, err => {
                _this.open3();
            });
            console.log("caonima");
            console.log(_this.nowOrg._id);
            console.log("happy")
            this.getOrg(_this.nowOrg);
            console.log(_this.org_msg);
            console.log("gengxinwancheng")
        },

        getOrg(v) {
            const _id = v._id;
            console.log(_id);
            console.log("Loading data");
            var serverPath = this.GLOBAL.serverSrc;
            let _this = this;
            axios.get(serverPath + '/organisations/' + _id + '/members/').then(res => {
                console.log(res)
                if (res.status == 200) {
                    console.log("success");
                    _this.org_msg = res.data.data;
                    console.log(_this.org_msg);

                } else {
                    console.log("false")
                }
            });
        },
        /* even: function(idRoles){
          return org_msg.filter(function(org_msg){
            return org_msg.role === idRoles
          })
        }, */
        resetDateFilter() {
            this.$refs.filterTable.clearFilter('date');
        },
        clearFilter() {
            this.$refs.filterTable.clearFilter();
        },
        formatter(row, column) {
            return row.phoneNumber;
        },
        filterTag(value, row) {
            return row.role === value;
        },
        filterHandler(value, row, column) {
            const property = column['property'];
            return row[property] === value;
        },
         handleClose () {
         this.activeName = 'first';
        },
        handleDelete(index, row) {
            console.log(this.nowOrg._id);
            console.log(row._id);
            let _this = this;
            let org_id = this.nowOrg._id;
            let mem_id = row._id;
            var serverPath = this.GLOBAL.serverSrc;
            axios.delete(serverPath + '/organisations/' + org_id + '/members/' + mem_id).then(res => {
                if (res.status == 200) {
                    console.log("success");
                    _this.open2();
                }
            }, err => {
                _this.open3();
            })
            this.dialogFormVisible2 = false;
            this.dialogFormVisible2 = true;
        },
        handleClick(tab, event) {
            console.log(tab, event);
        },
        open2() {
            this.$message({
                message: 'sucessful!',
                type: 'success'
            });
        },
        open3() {
            this.$message.error('Error! Something has Wrong');
        }

    }
}
</script>

<style>
 .card {
     width: 28%;
     position: relative;
     margin: 15px;
 }

 .icon {
     padding: 30px 50px;
     position: relative;
 }

 .create {
     width: 28%;
     position: relative;
     margin: 15px;
     text-align: center;

 }

 .text {
     font-size: 14px;
 }

 .item {
     margin-bottom: 20px;
 }

 .clear {
     clear: both;
     height: 0;
     line-height: 0;
     font-size: 0
 }

 .help {
     position: absolute;
     right: 40px;
     opacity: 0.5;
     
 }
 .help:hover{
   opacity: 1;
 }
</style>
