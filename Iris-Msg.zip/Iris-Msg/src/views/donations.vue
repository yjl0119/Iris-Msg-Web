<template>
  <div class="cube-wrap">
   


  </div>
</template>
<script>
    export default {
        
    }
</script>
