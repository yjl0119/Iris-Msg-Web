<template>
<html>
<body>
    <div id="demo">
    <h1>About Open Lab</h1>
    
   <p>
        Open Lab is one of the top ranked institutions at the ACM CHI Conference on Human Factors in Computing Systems, the premier international conference of Human-Computer Interaction. 

We embody the spirit of interdisciplinary research, many of our researchers have backgrounds in healthcare, community arts, urban planning, education, psychology and more. 
    </p>
    </div>
</body>
</html>
</template>
