<template>
  <div class="bg">
    <div class="block">
     <h3>1111111111111111111111111111111111111111111111111111111111111111</h3> 
    <el-carousel indicator-position="outside" :height="bannerHeight+'px'">
      <el-carousel-item v-for="item in imgUrls" :key="item.id">
        <el-row :gutter="24">
          <el-col :span="24" class="banner_img">
            <img ref="bannerHeight" :src="item.idView" class="bannerImg" @load="imgload()" />
          </el-col>
        </el-row>
      </el-carousel-item>
    </el-carousel>
  </div>
    <div class="login-wrap animated fadeIn">
      <h1>Iris Msg</h1>
      <h2>{{$t('SMS Donation Platform')}}</h2>
      <el-form ref="form" :model="form" :rules="rules" label-width="0px">
        <el-form-item prop="name">
          <el-input :placeholder="$t('Telephone Number')" v-model="form.name" clearable></el-input>
        </el-form-item>
         <p>{{alarmMessage1}}</p>
        <el-form-item>
          <el-button type="primary" @click="sendCode()" :disabled="codeDisabled">{{codeMsg}}</el-button>
        </el-form-item>
        <el-form-item prop="password">
          <el-input :placeholder="$t('SMS Code')" v-model="form.password"  clearable></el-input>
        </el-form-item>
        <p>{{alarmMessage2}}</p>
        <el-form-item>
          <el-button type="primary" @click="Login()">{{$t('Login')}}</el-button>
        </el-form-item>
      </el-form>
      <p>By tapping you are agreeing to our <a href="https://irismsg.io/"  target="_blank">terms of use</a> and <a href="https://irismsg.io/"  target="_blank">privacy policy</a></p>
    </div>
    <div>
      
    </div>
 </div>
</template>
<script>

import Vue from "vue";
import router from "../router/index";
import generateRoutes from "../router/parse";
import VueParticles from "vue-particles";
import axios from 'axios';
import { mapMutations } from 'vuex';

Vue.use(VueParticles);
export default {
  name: "signin",
  data() {
    return {
      form: {
        name: localStorage.userInfo || "",
        password: localStorage.passwordInfo || ""
      },
      isMemery: false,
      alarmMessage1:'',
      alarmMessage2:'',
      userToken:'',
      bannerHeight:'',
      imgUrls:[
        {id:0,idView:require('../assets/1.jpeg')},
        {id:1,idView:require('../assets/2.jpeg')},
        {id:2,idView:require('../assets/3.jpeg')},
        {id:3,idView:require('../assets/4.jpeg')},
      ],
      
      //Timer
      codeDisabled: false,
      countdown :60,
      codeMsg :'Send Code',
      timer :null
    };
  },
  methods: {
    ...mapMutations(['changeLogin']),
    sendCode(){
      if (/^(?:(?:\(?(?:0(?:0|11)\)?[\s-]?\(?|\+)44\)?[\s-]?(?:\(?0\)?[\s-]?)?)|(?:\(?0))(?:(?:\d{5}\)?[\s-]?\d{4,5})|(?:\d{4}\)?[\s-]?(?:\d{5}|\d{3}[\s-]?\d{3}))|(?:\d{3}\)?[\s-]?\d{3}[\s-]?\d{3,4})|(?:\d{2}\)?[\s-]?\d{4}[\s-]?\d{4}))(?:[\s-]?(?:x|ext\.?|\#)\d{3,4})?$/.test(this.form.name))
      {
        this.alarmMessage1=''
        const phoneNumber = this.form.name.substring(3)
        const countryCode = 'GB'
        console.log(phoneNumber)
        console.log(countryCode)
        var serverPath = this.GLOBAL.serverSrc;
        console.log(serverPath)
        axios.post(serverPath+'/users/login/request',{
          "phoneNumber" : phoneNumber,
          "countryCode" : countryCode
        })
        .then(res => {
          console.log(res)
          if (res.status == 200){
            this.codeDisabled = true;
             if (!this.timer) {
          this.timer = setInterval(() => {
            if (this.countdown > 0 && this.countdown <= 60) {
              this.countdown--;
              if (this.countdown !== 0) {
                this.codeMsg = "Retry after " + this.countdown + " seconds";
              } else {
                clearInterval(this.timer);
                this.codeMsg = "Send Code";
                this.countdown = 60;
                this.timer = null;
                this.codeDisabled = false;
              }
            }
          }, 1000)
        }
   }else{
            this.alarmMessage1 = 'The server is maintaining!'
            return false;
          }
        },err => {
                this.alarmMessage1 = 'Server request failed!';
            })
      }else{
        this.alarmMessage1 = 'This phone number is invaild!'
      }
    },
    Login(formName) {
      var Code = this.form.password
      if (/^\d{6}$/.test(Code)){
        this.alarmMessage2 = '';
        let _this = this;
        var serverPath = this.GLOBAL.serverSrc; 
        axios.post(serverPath+'/users/login/check',{
            "code" : Code
          })
          .then(res =>{
            console.log(res.data);
            if (res.status == 200){
            _this.alarmMessage2 = 'true';
            let data = res.data;
            console.log(data.data.token);
            _this.userToken = data.data.token;
            window.localStorage["token"] = _this.userToken;
            console.log(localStorage.token);
            this.getMenu();
            }
            },
            err =>{
              this.alarmMessage2 = 'Please input the correct number';
            })
      }else{
        _this.alarmMessage2 = 'Please input 6 digtal number';
        return false;
      }
    },
    getMenu() {
        let menu = [
        {
          name: "群组",
          name_en:"Organisations",
          router: "/organisations",
          icon: "el-icon-s-grid",
          children : []
        },
        {
          name: "捐献",
          name_en: "Donations",
          router: "/donations",
          icon: "el-icon-s-custom",
          children: []
        },
        {
          name: "捐献短信数量",
          name_en: "Donate Sms",
          router: "/donateNumber",
          icon: "el-icon-message-solid",
          children: []
        },
        {
          name: "关于",
          name_en: "About",
          router: "/",
          icon: "el-icon-paperclip",
          children: [
            {
              name: "关于Iris短信平台",
              name_en: "About Iris Msg",
              router: "/about1",
              icon: "el-icon-s-promotion",
            },
            {
              name: "关于开放实验室",
              name_en: "About Open Lab",
              router: "/about2",
              icon: "el-icon-s-opportunity",
            }
          ]
        }
      ];
        // 将原始数据进行本地存储
        localStorage.menu = JSON.stringify(menu);
        // 解析出路由配置表
        const _routes = generateRoutes(menu);
        // 动态加载路由配置表
        router.addRoutes(_routes);
        // 跳转到首页
        this.$router.push("/organisations");
      
    },
   
    imgLoad(){
       this.$nextTick(()=>{
         this.bannerHeight = this.$refs.bannerHeight[0].height
         console.log(this.$refs.bannerHeight[0].height);
       })
    }
  },
  mounted(){
    this.imgLoad();
    window.addEventListener('resize',() =>{
      this.bannerHeight = this.$refs.bannerHeight[0].bannerHeight
      this.imgLoad();
    },false)
  },
};
</script>

<style scoped lang="scss">
.bg {
  position: relative;
  overflow: hidden;
  height: 100%;
  display: flex;
  justify-content: center;
  align-items: center;
  background-image: url("../../static/img/bg.jpg");
  background-position: -20% 10%;
  background-size: contain;
  #particles-js {
    position: absolute;
    top: 0;
    bottom: 0;
    left: 0;
    right: 0;
  }
}
.login-wrap {
  width: 310px;
  padding: 30px;
  z-index: 3;
  margin-right: -40%;
  position: relative;
  background: rgba(50, 50, 50, 0.5);
  .el-form-item {
    margin-bottom: 25px !important;
  }
  h1 {
    text-align: center;
    color: #ebedef;
    margin-top: 0px;
    margin-bottom: 5px;
    font-size: 30px;
    span {
      color: #20a0ff;
    }
  }

  h2 {
    text-align: center;
    color: #ebedef;
    margin-top: 0px;
    margin-bottom: 5px;
    font-size: 20px;
    span {
      color: #20a0ff;
    }
  }
  p {
    text-align: center;
    color:#fff;
    margin:0;
    font-size: 10px;
    a {
      color:#f37747;
      text-decoration:underline;
    }
  }
  form {
    margin-top: 25px;
    .el-form-item {
      margin-bottom: 15px;
    }

  }
  a {
    text-decoration: none;
    color: #1f2d3d;
  }
  button {
    width: 100%;
    font-weight: 600;
    border:none;
    border-radius: 0;
    background-color: #f37747;
  }
  
}
.block{
  position: absolute;
  left:60px;
h3{
  opacity: 0;
}
 
}

 
</style>
