<template>
<html>
<body>
    <div id="demo">
    <h1>About Iris Msg</h1>
    <h3>a community SMS donation platform inspired by the Solidarity Economy</h3>
   <p>
        Iris was designed and developed by a number of people from Open Lab at Newcastle University and Open Lab: Athens. For more information about the people that took part in this check the team page.

Iris, is a system that allows sending SMS text messages to a list of subscribers through SMS donors. People supporting your organisation, group or case can sign up to become 'donors' and donate a number of SMS messages for your cause. Everytime that you need to send a text to a list of subscribers (e.g. volunteers, staff, followers etc.) you share the cost of the text messages sent. As a result, the communication of the organisation becomes more transparent and decentralised. Donors, through the Iris app, are able to see the content of the announcements sent, the subscription lists and sending and delivery reports.

Check the graphs below to better understand how Iris works. If you have any problems please contact us at info@olathens.com
    </p>
    </div>
</body>
</html>
</template>
